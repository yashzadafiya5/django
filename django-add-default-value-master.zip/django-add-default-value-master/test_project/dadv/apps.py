from django.apps import AppConfig


class DadvConfig(AppConfig):
    name = "dadv"
